/*
SSID du WIFI ainsi que le mot de passe
Modifier les paramètre WIFI pour le réseau auquels votre objets doit se brancher
*/

#define WIFI_SECRET_SSID "UNIFI_IDO1"
#define WIFI_SECRET_PASS "42Bidules!"

/*
Information nécessaire pour le branchement a un Broker MQTT
Dans le cadre du cours AIIA1013, ne modifié pas cet information
*/

#define SECRET_MQTT_SERVER_IP "198.164.130.74"
#define SECRET_MQTT_SERVER_PORT 1883

/*
Détails sur l'indentification de l'objet
Cette information provient de l'objet virtuel créer sur le serveur Thingsbord
*/

#define SECRET_TOKEN  "XqRx38exnr8rnsLHo0VS"
#define SECRET_DEVICE_ID "d4d98b30-759f-11ed-8fd7-e3d583114459"



